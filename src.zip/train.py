import torch
from torch.utils.data import DataLoader
from tqdm import tqdm as tqdm
from data import Stenosis_Dataset
from UNet import UNet
import multiprocessing
import matplotlib.pyplot as plt
import numpy as np
import os

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = UNet().to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = torch.nn.CrossEntropyLoss(weight=torch.tensor([1.0, 10.0], device=device))
lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=10)

train_set = Stenosis_Dataset(mode="train")
train_loader = DataLoader(train_set, batch_size=4, shuffle=True, num_workers=4, drop_last=True)

val_set = Stenosis_Dataset(mode="val")
val_loader = DataLoader(val_set, batch_size=4, shuffle=False, num_workers=4, drop_last=False)

"""
drop_last is an argument in PyTorch's DataLoader that determines how to handle the 
last batch of data if the dataset size is not divisible by the batch size.
"""


def save(model, epoch_id=0):
    os.makedirs('models', exist_ok=True)
    torch.save(model.state_dict(), os.path.join('models', str(epoch_id) + '.pt'))

def load(model, epoch_id=0):
    model.load_state_dict(torch.load(os.path.join('models', str(epoch_id) + '.pt')))

def visualize_train(epoch, train_batch_ids, train_losses):
    plt.plot(train_batch_ids, train_losses)
    plt.xlabel("step")
    plt.ylabel("loss")
    plt.title(f"Training Curve in Epoch {epoch}")
    plt.savefig(f"./curves/train/{epoch}.png")

def visualize_eval(eval_ids, eval_score):
    plt.plot(eval_ids, eval_score)
    plt.xlabel("epoch")
    plt.ylabel("F1 score")
    best_model_epoch=eval_ids[np.argmax(np.array(eval_score))]

    plt.axvline(best_model_epoch,c='red')
    plt.title(f"Evaluation Result in Different Epochs"+"\n"+f"Best Model is in Epoch {best_model_epoch}")
    plt.savefig(f"./curves/eval/{epoch}.png")

def log_output(epoch, lr_scheduler, train_losses,eval_score):
    f.write(f"epoch: {epoch}\t")
    f.write(f"lr: {lr_scheduler.get_last_lr()[0]}\t")
    f.write(f"train_loss: {train_losses[-1]}\t")
    f.write(f"eval_score: {eval_score[-1]}\n")

if __name__=="__main__":

    # prepare for logging
    train_batch_ids=[]
    train_losses=[]
    eval_ids=[]
    eval_score=[]
    
    # prepare for visualization
    os.makedirs('curves/eval', exist_ok=True)
    os.makedirs('curves/train', exist_ok=True)
    best_model_state_dict=dict()

    with open("logger_file.txt", "w+") as f:
        # Prevent the submodules from starting a multiple process prematurely
        multiprocessing.freeze_support()
        for epoch in range(10):
            print(f"EPOCH: {epoch}/10")
            # Train the model, single pass through the entire training set
            model.train()
            for batch_idx, (inputs, masks) in tqdm(enumerate(train_loader)):
                inputs, masks = inputs.to(device), masks.to(device)

                predicted_masks = model(inputs)
                loss = criterion(predicted_masks, masks)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                # if batch_idx ==1:
                #     break
                if batch_idx % 10 == 0:
                    print(f"batch_idx: {batch_idx}, train_loss: {loss.item()}")
                    train_batch_ids.append(batch_idx)
                    train_losses.append(loss.item())
            lr_scheduler.step()
            # visulize training curve in this epoch
            visualize_train(epoch, train_batch_ids, train_losses)
            
            # Evaluate the model.
            model.eval()
            with torch.no_grad():
                total_samples, total_f1_score = 0, 0
                for batch_idx, (inputs, masks) in tqdm(enumerate(val_loader)):
                    # move to gpu.
                    inputs, masks = inputs.to(device), masks.to(device)

                    # the predicted masks are floating point tensors in [0,1]
                    predicted_masks = model(inputs)

                    # decision-making to convert soft decision in [0,1] to hard decision in {0,1}
                    predicted_masks = predicted_masks[:, 1, :, :] > predicted_masks[:, 0, :, :]

                    # evaluate the prediction by precision and recall.
                    tp = (masks * predicted_masks).sum()         # actually one, and you take it just as one.
                    fp = ((1 - masks) * predicted_masks).sum()   # actually zero, but you take it as one.
                    fn = (masks * ~predicted_masks).sum()        # actually one, but you take it as zero.
                    f1 = tp / (tp + 0.5 * (fp + fn))
                    
                    total_samples += inputs.size(0)
                    total_f1_score += f1 * inputs.size(0)
                
                average_f1_score=total_f1_score / total_samples
                print(f"val_f1_score: {average_f1_score}")

                eval_ids.append(epoch)
                eval_score.append(average_f1_score)
            
            # log
            log_output(epoch, lr_scheduler, train_losses,eval_score)
            
            # save the model
            save(model, epoch_id=epoch)
        
        # visualize evaluatoin result across epochs
        visualize_eval(eval_ids, eval_score)
